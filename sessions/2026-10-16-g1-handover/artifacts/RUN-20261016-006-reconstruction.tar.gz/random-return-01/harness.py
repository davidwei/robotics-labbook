"""Temporary lab harness. Default is read-only; --motion requires operator confirmation."""
import argparse
import json
import os
import subprocess
import sys
import time
from collections import deque
from dataclasses import asdict
from pathlib import Path

import numpy as np

from lerobot.robots.unitree_g1.g1_arm_sdk import ARM_SLOTS, ArmSDKTransport, G1ArmSDK, G1ArmSDKConfig
from lerobot.robots.unitree_g1.g1_vr_control import ARM_KEYS


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def sample(arm):
    with arm.feedback_lock:
        state = arm._snapshot()
        return dict(at=time.monotonic(), tick=arm.tick, mode=arm.mode,
                    age_s=time.monotonic()-arm.state_at,
                    q=[state.motor_state[s].q for s in ARM_SLOTS],
                    dq=[state.motor_state[s].dq for s in ARM_SLOTS])


class CaptureTransport(ArmSDKTransport):
    def __init__(self, rows):
        self.rows = rows
        self.arm = None
        self.closed_at = None
        self.capture_dropped = 0

    def write(self, command):
        # Bounded in-memory capture: no filesystem I/O in the publisher thread.
        if self.rows.maxlen is not None and len(self.rows) == self.rows.maxlen:
            self.capture_dropped += 1
        with self.arm.feedback_lock:
            state = self.arm.state
            row = dict(at=time.monotonic(), phase=self.arm.handover_phase, experiment_phase=getattr(self.arm, 'experiment_phase', 'preflight'),
                       tick=self.arm.tick, age_s=time.monotonic()-self.arm.state_at,
                       measured_q=[state.motor_state[s].q for s in ARM_SLOTS],
                       measured_dq=[state.motor_state[s].dq for s in ARM_SLOTS],
                       q=[command.motor_cmd[s].q for s in ARM_SLOTS],
                       tau=[command.motor_cmd[s].tau for s in ARM_SLOTS],
                       weight=command.motor_cmd[29].q, written=False)
        self.rows.append(row)
        super().write(command)
        row['written'] = True
        row['written_at'] = time.monotonic()


    def close(self):
        super().close()
        self.closed_at = time.monotonic()

def observer(root):
    arm = G1ArmSDK(G1ArmSDKConfig(network_interface=os.environ['G1_DDS_IFACE']))
    try:
        arm.connect()
        with (root/'feedback.jsonl').open('x') as f:
            deadline = time.monotonic()+3600
            while time.monotonic() < deadline:
                row = sample(arm)
                assert not arm.writer and not arm.active
                f.write(json.dumps(row)+'\n'); f.flush()
                (root/'observer-ready').touch()
                closed = root/'publisher-closed.json'
                if not closed.exists():
                    closed = root/'observer-stop.json'
                if closed.exists() and row['at'] >= json.loads(closed.read_text())['at']+5:
                    break
                time.sleep(.01)
            else:
                raise RuntimeError('Observer timed out without completed post-close capture')
    finally:
        arm.close()


def control(root, motion):
    scenario_id = int(os.environ["G1_RETURN_SCENARIO"])
    manifest = json.loads(Path("/tmp/g1-handover-ready/random-return-scenarios.json").read_text())
    scenario = manifest["scenarios"][scenario_id-1]
    dump(root/"scenario.json", scenario)
    goal_degrees = scenario["left"] + scenario["right"]
    from lerobot.robots.unitree_g1.g1_safety_contract import model_limits
    from lerobot.robots.unitree_g1.g1_vr_assets import resolve_g1_vr_assets
    assets = Path(resolve_g1_vr_assets(None))
    urdf = assets/'assets/g1_body29_hand14.urdf'
    limits = model_limits(urdf)
    cfg = G1ArmSDKConfig(network_interface=os.environ['G1_DDS_IFACE'], read_only=not motion, unitree_gating=True,
        expected_mode_machine=5, kp=[60.]*14, kd=[1.5]*14,
        lower=limits['lower'], upper=limits['upper'],
        torque_limits=[min(15., x) for x in limits['effort']], gravity_urdf=str(urdf),
        period_s=.02, max_velocity=.05, max_acceleration=.05, max_displacement=1.5,
        max_tracking_error=.08, max_measured_velocity=.1, max_wrist_displacement=None,
        workspace_lower=[-.02,-.5,-.5],workspace_upper=[1.,.5,.5],
        blend_s=5., start_position=[], start_tolerance=.05, return_velocity=.05, return_timeout_s=120.)
    dump(root/'config.json', asdict(cfg))
    rows=deque(maxlen=50000); io=CaptureTransport(rows); arm=G1ArmSDK(cfg, transport=io); io.arm=arm
    try:
        arm.connect()
        baseline=[]
        for _ in range(100):
            baseline.append(sample(arm)); time.sleep(.02)
        dump(root/'baseline.json', baseline)
        q=np.array(baseline[-1]['q'])
        goal=np.deg2rad(goal_degrees)
        dump(root/'precheck.json', dict(start_q=q.tolist(), planned_inspection_q=goal.tolist(), writer=arm.writer, unitree_gating=cfg.unitree_gating))
        if motion:
            path = np.concatenate([np.linspace(q, goal, 501), np.linspace(goal, np.zeros(14), 501)])
            for pose in path:
                arm._check_pose(pose)
                arm._check_wrist_displacement(pose)
            peak = max(float(np.max(np.abs(arm.gravity.gravity(pose)))) for pose in path)
            delta=float(np.max(abs(goal-q)))
            duration=max(1.875*delta/cfg.max_velocity,np.sqrt(10/np.sqrt(3)*delta/cfg.max_acceleration),1.)
            dump(root/'lowering-plan.json',dict(duration_s=duration,peak_gravity_torque=peak,
                target_speed_rad_s=cfg.max_velocity,start=q.tolist(),goal=goal.tolist()))
            print(f'Preflight passed. Inspection-pose move duration approximately {duration:.1f} seconds.',flush=True)
            if input('Type MOVE to begin the authorized inspection-pose and hold test: ') != 'MOVE':
                raise RuntimeError('Motion not confirmed')
            from lerobot.robots.unitree_g1.g1_voice import G1FollowingVoice
            voice = G1FollowingVoice()
            voice.say('Robot arms will move slowly to the inspection position in five seconds.')
            print('Robot arms will move slowly to the inspection position in five seconds. Emergency control remains with operator.',flush=True)
            time.sleep(5)
            arm.experiment_phase='takeover_hold'
            arm.activate()
            # Preserve the activation snapshot; no initial target jump.
            q=arm.initial.copy()
            goal=np.deg2rad(goal_degrees)
            delta=float(np.max(abs(goal-q)))
            duration=max(1.875*delta/cfg.max_velocity,np.sqrt(10/np.sqrt(3)*delta/cfg.max_acceleration),1.)
            dump(root/'activated-plan.json',dict(start=q.tolist(),goal=goal.tolist(),duration_s=duration))
            elapsed=0.; previous=time.monotonic(); started=previous; last_status=0.; reached_at=None
            paused=False; target=q.copy(); handover=False
            while True:
                now=time.monotonic();dt=min(now-previous,.04);previous=now
                command=root/'command'
                if command.exists():
                    request=command.read_text().strip();command.unlink()
                    if request=='pause':
                        paused=True
                        with arm.lock:
                            target=arm.previous.copy()
                        voice.say('Paused. Holding arms.')
                    elif request=='handover' and arm.experiment_phase=='inspection_hold':
                        handover=True;break
                if now-started >= 6 and not paused:
                    elapsed=min(duration,elapsed+dt)
                    u=elapsed/duration
                    target=q+(goal-q)*(10*u**3-15*u**4+6*u**5)
                    arm.experiment_phase='positioning' if elapsed<duration else 'settling'
                if paused:
                    arm.experiment_phase='paused_hold'
                arm.send(dict(zip(ARM_KEYS,target.tolist(),strict=True)))
                measured=sample(arm)
                if elapsed>=duration and np.max(np.abs(np.array(measured['q'])-goal))<.04 and max(abs(x) for x in measured['dq'])<.05:
                    reached_at=now if reached_at is None else reached_at
                    if now-reached_at>=1:
                        if not (root/'inspection-held').exists():
                            message='Arms at the inspection position. Holding. Please inspect.'
                            print(message,flush=True)
                            voice.say(message)
                            (root/'inspection-held').write_text(str(now))
                        arm.experiment_phase='inspection_hold'
                else:
                    reached_at=None
                if now-last_status>=1:
                    dump(root/'status.json',dict(at=now,phase=arm.experiment_phase,elapsed=elapsed,
                        duration=duration,q=measured['q'],dq=measured['dq'],weight=arm.weight,
                        fault=arm.fault,command_count=len(rows)))
                    last_status=now
                time.sleep(.02)
            print('Operator requested handover from inspected random inspection pose.',flush=True)
            voice.say('Returning control to the stock controller.')
        else:
            assert not arm.writer and not arm.active and not rows
    finally:
        try:
            arm.close()
        finally:
            marker='publisher-closed.json' if io.closed_at is not None else 'observer-stop.json'
            dump(root/marker, dict(at=io.closed_at or time.monotonic(),closure_verified=io.closed_at is not None,phase=arm.handover_phase,
                writer_created=arm.writer,return_succeeded=arm.return_succeeded,fault=arm.fault))
            dump(root/'commands.json',list(rows))
            dump(root/'capture-summary.json',dict(command_rows=len(rows),dropped_command_rows=io.capture_dropped))


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--observer',action='store_true');p.add_argument('--motion',action='store_true')
    args=p.parse_args();root=args.root
    if args.observer:
        observer(root);return
    root.mkdir(parents=True,exist_ok=False)
    (root/'harness.py').write_bytes(Path(__file__).read_bytes())
    dump(root/'provenance.json',dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        mode='motion' if args.motion else 'read-only',hostname=os.uname().nodename))
    (root/'code.patch').write_bytes(subprocess.check_output(['git','diff','HEAD']))
    with (root/'observer.log').open('x') as log:
        child=subprocess.Popen([sys.executable,__file__,'--observer','--root',str(root)],stdout=log,stderr=log)
        try:
            deadline=time.monotonic()+30
            while not (root/'observer-ready').exists():
                if child.poll() is not None or time.monotonic()>deadline:
                    raise RuntimeError('Independent observer failed to start')
                time.sleep(.1)
            control(root,args.motion)
        finally:
            if not (root/'publisher-closed.json').exists() and not (root/'observer-stop.json').exists():
                dump(root/'observer-stop.json',dict(at=time.monotonic(),phase='not_started',closure_verified=False))
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.terminate();child.wait(timeout=5)
        if child.returncode:
            raise RuntimeError('Independent observer failed; inspect observer.log')
    feedback=[json.loads(x) for x in (root/'feedback.jsonl').read_text().splitlines()]
    closed=json.loads((root/'publisher-closed.json').read_text())
    assert closed['closure_verified']
    result=dict(feedback_samples=len(feedback),post_close_s=feedback[-1]['at']-closed['at'],
        max_feedback_age_s=max(r['age_s'] for r in feedback),
        max_arm_speed=max(abs(v) for r in feedback for v in r['dq']),
        unique_ticks=len({r['tick'] for r in feedback}),closed=closed)
    assert result['post_close_s']>=5
    dump(root/'summary.json',result);print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()

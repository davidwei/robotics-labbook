# RUN-006 evidence timeline

Times are relative to the first return command (monotonic 7032.808874161 s). This avoids inventing wall-clock precision. No simulation was built or run.

| Relative time | Recorded event |
|---:|---|
| -125.15 s | inactive / takeover_hold |
| -119.14 s | inactive / positioning |
| -73.70 s | inactive / settling |
| +0.00 s | return / settling |
| +2.91 s | First return sample with any arm |dq| ≥ 1 rad/s |
| +6.49 s | First return sample with any arm |dq| ≥ 3 rad/s |
| +6.92 s | First return sample with any arm |dq| ≥ 5 rad/s |
| +7.66 s | First return sample with any arm |dq| ≥ 10 rad/s |
| +8.96 s | First return sample with any arm |dq| ≥ 20 rad/s |
| +43.21 s | First return sample with any arm |dq| ≥ 30 rad/s |
| +120.04 s | Return timed out; publisher closure verified; no fade |
| +125.07 s | Independent post-close feedback capture ended |

Before return, the final 10 seconds were nearly stationary (largest measured arm speed about 0.041 rad/s). The preparation itself had an earlier 2.69 rad/s peak. Inspection was never automatically declared: shoulder position residuals exceeded 0.04 rad. Operator confirmed position; main-process SIGINT invoked central return. This bypassed scripted inspection/handover announcements and is a protocol deviation.

At return entry, the largest target change was 0.069507 rad (3.98 degrees). For the left shoulder pitch, target changed from about -0.0175 to -0.0870 rad while measured q remained about -0.0880 rad. With kp=60, this changes the position-error contribution by approximately -4.17 Nm; this is an algebraic command-law estimate, not measured torque. Feedforward remained the last published vector, including left/right shoulder-pitch values about -3.74/-3.73 Nm.

The return target follows the latest measured q with a maximum 0.001-rad offset toward zero. This is not a 0.05-rad/s bound on measured speed or successive published targets. There were 4,431 return publications at weight 1, no measured arrival, no fade, and a 120-second timeout. All 8,974 captured writes returned successfully and no capture rows were dropped; this is not a firmware execution ACK.

The largest publication gap was 0.332 s at return -4.61 s, during the preceding hold. This is recorded context, not an established cause.

Operator sequence (not precisely timestamped): robot moved forward/waist bent; arms oscillated with growing amplitude and did not stop; operator used emergency stop to enter damp mode. Exact emergency-stop time relative to closure is unknown. All captured mode fields were (5,0); these do not independently establish the intervention time.

| Joint | Minimum SDK degrees | Maximum SDK degrees | Full observed range |
|---|---:|---:|---:|
| R shoulder pitch | -123.9 | 73.1 | 197.0 |
| L shoulder pitch | -95.1 | 80.8 | 175.8 |
| R elbow | -33.7 | 114.2 | 147.9 |
| L elbow | -17.3 | 94.3 | 111.6 |
| L shoulder roll | -10.8 | 100.4 | 111.2 |
| R shoulder roll | -66.4 | 11.4 | 77.9 |

These ranges span the return window; they are not all single-cycle amplitudes. Right shoulder pitch does traverse +73.13 degrees at +18.197 s to -123.87 degrees at +18.901 s. Root cause remains unresolved.

# Environment inventory

Captured after the lab run; this is dependency provenance, not a complete binary environment or tested lockfile. Conda package build specs and Python distribution inventory cover the installed environment. Pinocchio is recorded via conda metadata (3.9.0), filling the missing pip distribution metadata in the original capture. Package inventories contain no credential-bearing source URLs or shell environment dump.

Unitree SDK tracked source and the installed aarch64 CRC library are included. The PC2 environment helper is included; the minimal profile records only the DDS interface. Original launch paths are PC2-specific: adapt paths and restore archived harness.py as inspect_random.py if examining the launcher. Offline analysis/simulation should not launch the physical harness or initialize DDS. G1_RETURN_SCENARIO=1 selects RUN-006.

System JetPack/NVIDIA libraries, proprietary stock controller/firmware, and all conda/pip package binaries are not included. Rebuilding on a different architecture requires compatible packages; matching the recorded versions is not a guarantee of hardware-equivalent dynamics. No simulation or hardware operation was performed for this export.

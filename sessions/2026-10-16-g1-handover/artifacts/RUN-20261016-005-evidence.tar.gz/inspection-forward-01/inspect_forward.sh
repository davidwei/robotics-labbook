#!/bin/bash
set -euo pipefail
python_bin=/home/dwei/miniforge3/envs/lerobot-dev/bin/python
lerobot_dir=/home/dwei/lerobot
source /home/dwei/unitree_g1_dev/pc2/IsaacTeleop/lerobot_env.sh
source /home/dwei/unitree_g1_dev/pc2/g1_pc2_hardware.env
export G1_DDS_IFACE
lerobot_environment
cd /home/dwei/lerobot
exec /home/dwei/miniforge3/envs/lerobot-dev/bin/uv run --no-project --python "$python_bin" python /tmp/g1-handover-ready/inspect_forward.py "$@"

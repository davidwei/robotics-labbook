import importlib.util,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
spec=importlib.util.spec_from_file_location('lower','/tmp/g1-handover-ready/inspect_forward.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
clock=[0.]; root=Path(tempfile.mkdtemp(prefix='g1-lower-mock-'));targets=[];held=[None];closed=[];spoken=[]
class Arm:
 def __init__(self,cfg,transport):
  self.config=cfg;self.writer=False;self.active=False;self.initial=np.full(14,.2);self.q=self.initial.copy();self.weight=1.;self.fault=None;self.handover_phase='inactive';self.return_succeeded=False;self.gravity=SimpleNamespace(gravity=lambda q:np.zeros(14))
 def connect(self):pass
 def _check_pose(self,q):pass
 def _check_wrist_displacement(self,q):pass
 def activate(self):self.active=self.writer=True
 def send(self,action):
  self.q=np.array(list(action.values()));targets.append((clock[0],self.q.copy()))
 def close(self):closed.append(clock[0]);self.active=False

def sleep(dt):
 clock[0]+=dt
 if (root/'inspection-held').exists():
  if held[0] is None:held[0]=clock[0]
  assert not closed
  if clock[0]-held[0]>=5:(root/'command').write_text('handover')
 if clock[0]>300:raise RuntimeError('Mock flow failed to finish')

def sample(a):return dict(at=clock[0],tick=1,mode=(5,0),age_s=0,q=a.q.tolist(),dq=[0.]*14)
with patch.object(m,'G1ArmSDK',Arm),patch.object(m,'sample',sample),patch.object(m.time,'monotonic',lambda:clock[0]),patch.object(m.time,'sleep',sleep),patch('builtins.input',lambda _: 'MOVE'),patch('lerobot.robots.unitree_g1.g1_voice.G1FollowingVoice',lambda:SimpleNamespace(say=lambda message:spoken.append(message))):
 m.control(root,True)
assert held[0] is not None and closed[0]-held[0]>=5
assert np.allclose(targets[0][1],.2)
assert np.allclose(targets[-1][1],np.zeros(14))
for (ta,qa),(tb,qb) in zip(targets,targets[1:]):
 assert np.max(abs(qb-qa))<=.05001*(tb-ta)
assert spoken.count('Arms at the inspection position. Holding. Please inspect.')==1
print('PASS: measured-pose takeover; target speed <=0.05 rad/s; inspection hold persisted 5s; closure only after explicit handover request; English inspection voice exactly once')
